﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TravellerWiki.Data
{
    public class TravellerMissionGeneratorService
    {/*
        public async Task<List<TravellerSpecialNPC>> GetMissionAsync()
        {
        }*/
    }
}
